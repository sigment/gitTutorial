Nothing magic. Just see this page for creating your own standalone windows installers:
https://docs.python.org/3.4/distutils/builtdist.html
